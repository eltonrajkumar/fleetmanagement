package com.elton.fleetmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FleetmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
