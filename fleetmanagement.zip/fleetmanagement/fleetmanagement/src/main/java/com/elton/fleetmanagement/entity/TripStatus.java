package com.elton.fleetmanagement.entity;

public enum TripStatus {
    ONGOING,
    COMPLETED
}
