package com.elton.fleetmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FleetmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(FleetmanagementApplication.class, args);
	}

}
